import { useState, useEffect } from "react";
import { Routes, Route } from "react-router-dom";
import { Navigate } from "react-router-dom";


import Navbar from "./components/Navbar";
import About from "./components/About";
import Accordion from "./components/Accordion";
import Footer from "./components/Footer";

import "./App.css";

function App() {
  const [darkMode, setDarkMode] = useState(false);

  const toggleDarkMode = () => setDarkMode(prev => !prev);

  useEffect(() => {
    document.body.style.backgroundColor = darkMode ? "#121212" : "#ffffff";
    document.body.style.color = darkMode ? "white" : "black";
  }, [darkMode]);

  return (
    <>
      <Navbar toggleDarkMode={toggleDarkMode} darkMode={darkMode} />

      <Routes>
       <Route path="/" element={<Navigate to="/profile" replace />} />
       <Route path="/profile" element={<About darkMode={darkMode} />} />
       <Route path="/others" element={<Accordion darkMode={darkMode} />} />
      </Routes> 
      <Footer darkMode={darkMode} />
    </>
  );
}

export default App;
