import React from "react";
import profilePic from "../assets/images/cat.jpg"; 

export default function About({ darkMode }) {
  return (
    <section
      className="py-5"
      id="about-me"
      style={{
        backgroundColor: darkMode ? "#1e1e1e" : "#f8f9fa",
        color: darkMode ? "white" : "black",
        transition: "background-color 0.5s, color 0.5s",
      }}
    >
      <div className="container">
        <div className="row align-items-center">
          <div className="col-md-4 text-center">
            <img
              src={profilePic}
              alt="Profile"
              className="img-fluid rounded-circle shadow"
              style={{ maxWidth: "220px" }}
            />
          </div>

          <div className="col-md-8">
            <h2>About Me</h2>
            <p className="lead">Hello. I am Zhawn Lopez.</p>
            <p>I am currently a 2nd Year Computer Science student and I enjoy experimenting with different games stuff yeah. One of my favorite things is discovering unique ideas from people and their work.</p>
            <p> <i> i am currently dying theres so much jumble </i></p>
            <a href="#games" className={`btn mt-2 ${darkMode ? "btn-light" : "btn-primary"}`}>
              My Game Picks 🎮 (don't actually press this, it doesn't exist yet)
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
